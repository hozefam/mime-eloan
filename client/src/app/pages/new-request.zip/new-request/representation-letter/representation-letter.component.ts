import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'representation-letter',
  templateUrl: './representation-letter.component.html',
  styleUrls: ['./representation-letter.component.scss']
})
export class RepresentationLetterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
