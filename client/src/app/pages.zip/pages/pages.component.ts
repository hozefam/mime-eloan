import { Component, Output , EventEmitter  } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { MENU_ITEMS } from './pages-menu';
import { Router } from '@angular/router';
import { NbMenuItem } from "@nebular/theme";
import { createElementCssSelector } from '../../../node_modules__/@angular/compiler';

@Component({
  selector: 'ngx-pages',
  template: `
 <ngx-sample-layout>
   <nb-menu  [items]="menu"></nb-menu>
   <router-outlet></router-outlet>
 </ngx-sample-layout>   
  `,
styleUrls:['./pages-menu.component.scss']
})
export class PagesComponent {
  menu = MENU_ITEMS;
   logedInHomePage : boolean = false ; 
  
  constructor(private router: Router ,private translate: TranslateService) {
    this.logedInHomePage =  (this.router.url.toString().includes('ihome') ) ?true : false; 
     console.log(this.router.url.toString())
  } 
  ngOnInit()
	{
		this.menu = MENU_ITEMS;
		this.translate.onLangChange.subscribe( event => this.translateMenuItems() );
		this.translateMenuItems();
	}

	translateMenuItems()
	{
		console.log('menu');
		console.log(this.menu);
		this.menu.forEach( item =>
			
			{
				if(item.children){
					this.translateMenuItem( item );
					item.children.forEach( item2 => this.translateMenuItem( item2 ));
				}
				else
				this.translateMenuItem( item );
			});
	}

	translateMenuItem( menuItem: NbMenuItem )
	{
    
    
		menuItem.title = this.translate.instant( menuItem.data );
	}
}
