import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'certificate-requests',
  templateUrl: './certificate-requests.component.html',
  styleUrls: ['./certificate-requests.component.scss']
})
export class CertificateRequestsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
