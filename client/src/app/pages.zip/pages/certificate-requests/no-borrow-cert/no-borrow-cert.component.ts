import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'no-borrow-cert',
  templateUrl: './no-borrow-cert.component.html',
  styleUrls: ['./no-borrow-cert.component.scss']
})
export class NoBorrowCertComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
