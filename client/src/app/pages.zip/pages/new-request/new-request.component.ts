import { Component, OnInit , EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'new-request',
  templateUrl: './new-request.component.html',
  styleUrls: ['./new-request.component.scss']
})
export class NewRequestComponent implements OnInit  {

  constructor() { }
   
  ngOnInit() {
  }
  
}
